//app.js
App({
  //onLaunch,onShow: options(path,query,scene,shareTicket,referrerInfo(appId,extraData))
  onLaunch: function(options){
    // 云数据库初始化操作
    wx.cloud.init({
        // 环境：需要填写环境ID
        env:'icecloud1-1gqhw9il8fca2a16',
        traceUser:true
    })
    
  },
  onShow: function(options){

  },
  onHide: function(){

  },
  onError: function(msg){

  },
  //options(path,query,isEntryPage)
  onPageNotFound: function(options){

  }
  
});