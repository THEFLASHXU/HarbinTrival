//Page Object
//获取数据库引用
wx.cloud.init()
const db=wx.cloud.database()
Page({
    data: {
        //轮播图数组
        swiperList:[]
    },
    //options(Object)
    //页面开始加载的时候就会触发
    onLoad: function(options) {
        
    },
    onReady: function() {
        
    },
    onShow: function() {
        
    },
    onHide: function() {

    },
    onUnload: function() {

    },
    onPullDownRefresh: function() {

    },
    onReachBottom: function() {

    },
    onShareAppMessage: function() {

    },
    onPageScroll: function() {

    },
    //item(index,pagePath,text)
    onTabItemTap:function(item) {

    }
});
  