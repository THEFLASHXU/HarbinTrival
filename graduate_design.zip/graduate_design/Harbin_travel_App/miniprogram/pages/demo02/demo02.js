// pages/demo02/demo02.js
Page({
	/**
	 * 页面的初始数据
	 */
	data: {
		imgCloud: '', //照片的云存储地址
        imgUrl: '', //照片的真实地址
        arrImg:[]//图片对象数组,前端循环显示内容
	},

	uploadImg() {
		wx.chooseMessageFile({
            count:9,
            type:"image",
			success: (res) => {
                this.setData({
                    arrImg:res.tempFiles
                })
                console.log(this.data.arrImg);
                this.data.arrImg.forEach((item,idx)=>{
                    var filePath=item.path//文件的临时路径
                    var fileName=item.time+"_"+item.name//文件的存储名称
                    this.cloudFile2(filePath,fileName)
                })
				
			},
		})
	},
    cloudFile2(path,fileName){
        wx.cloud
			.uploadFile({//cloudpath：云端文件名
                cloudPath:fileName,
				filePath: path,
			})
			.then((res) => {
				console.log(res);
			})
    },

	cloudFile(path,fileName) {//path:临时路径，fileName：文件名
		var cloudImg
		wx.showLoading({
			title: '图片上传中',
		})
		wx.cloud
			.uploadFile({//cloudpath：云端文件名
                //cloudPath: Date.now() + '.jpg',
                cloudPath:fileName,
				filePath: path,
			})
			.then((res) => {
				this.setData({
					imgCloud: res.fileID,
				})
				wx.hideLoading()

				console.log('imgCloud1是')
                
				console.log(this.data.imgCloud)
				this.getRealUrl_img(this.data.imgCloud)
			})
	},

	getRealUrl_img(cloudUrl) {
		console.log('函数getRealUrl_img：cloudUrl是：')
		console.log(cloudUrl)
		wx.cloud
			.getTempFileURL({
				//寻找出图片的真实路径并存储进云数据库
				fileList: [
					{
						fileID: cloudUrl,
					},
				],
			})
			.then((res) => {
				// console.log('filelist是：')
				// console.log(res.fileList)
                // console.log('函数getRealUrl_img：tempFileURL是：')
                
				// console.log(res.fileList[0].tempFileURL)
				this.setData({
					imgUrl: res.fileList[0].tempFileURL,
				})
				 console.log('imgUrl是')
				 console.log(this.data.imgUrl)
            })
            .catch(error=>{
                console.log(error);
            })
		
	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {},
	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {},
})
