// pages/buy/buy.js
Page({
	/**
	 * 页面的初始数据都放在data中
	 */
	data: {
		num: 0,
		number1: 0,
		number2: 0,
		gender: '',
		Tabs: [
			{
				id: 0,
				name: '首页',
				isActive: true,
			},
			{
				id: 1,
				name: '原创',
				isActive: false,
			},
			{
				id: 2,
				name: '分类',
				isActive: false,
			},
			{
				id: 3,
				name: '关于',
				isActive: false,
			},
		],
	},
	//自定义事件，接收子组件传递的数据
	handleItemChange(e) {
		//console.log(e);
		//接受传递过来的参数
		const { index } = e.detail
		let { Tabs } = this.data
		Tabs.forEach((v, i) =>
			i === index ? (v.isActive = true) : (v.isActive = false)
		)
		this.setData({
			Tabs,
		})
	},
	//输入框的input事件执行
	Handleinput(e) {
		this.setData({
			num: e.detail.value,
		})
		//console.log(e.detail.value);
	},
	handletap(e) {
		// console.log(e);
		const operation = e.currentTarget.dataset.operation
		this.setData({
			num: this.data.num * 1 + operation,
		})
	},
	UtilTap(e) {
		const change = e.currentTarget.dataset.operation
		this.setData({
			number1: this.data.number1 + change,
			number2: this.data.number2 + 1,
		})
	},
	getGender(e) {
		// console.log(e);
		let gender = e.detail.value
		this.setData({
			gender: gender,
		})
	},
	//获取手机号码
	getPhone(e) {
		console.log(e)
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {},
})
