// pages/demo03/demo03.js
var db = wx.cloud.database(); //初始化连接数据库
Page({

  /**
   * 页面的初始数据
   */
  data: {
    img_TmpPath: [], //图片临时路径
    video_TmpPath: "", //视频临时路径
    img_width: 0 //图片宽度
  },
  //选择视频上传功能
  uploadVidBtn() {
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      compressed: true,
      maxDuration: 60,
      success: (res) => {
        //上传视频的时候返回的tempfilepaths是一个字符串，而不是字符串数组，要和图片部分加以区别
        //   this.uploadVidio_toCloud(new Date().getTime()+".mp4",res.tempFilePath)
        this.setData({
          video_TmpPath: res.tempFilePath
        })
      },
      fail: () => {},
      complete: () => {}
    });
  },
  //上传视频到云存储
  uploadVideo_toCloud() {
    wx.showLoading({
      title: '视频上传中...',
    })
    var tmpPath = this.data.video_TmpPath

    wx.cloud.uploadFile({
      cloudPath: new Date().getTime() + ".mp4",
      filePath: tmpPath, // 文件临时路径
    }).then(res => {
      // get resource ID
      console.log(res)
      wx.hideLoading({
        
      })
      // this.setData({
      //     video_TmpPath:res.fileID
      // })
      wx.showToast({
        title: '视频上传成功',
      })
    }).catch(error => {
      // handle error
    })

  },



  btnAdd: function () {
    db.collection("clouddemo")
    console.log(123);
  },
  //选择图片功能
  uploadImgBtn() {
    wx.chooseImage({
      count: 9, // 默认为9
      sizeType: ['compressed'], // 指定原图或者压缩图
      sourceType: ['album', 'camera'], // 指定图片来源
      success: (res) => {
        //var tempFilePaths = res.tempFilePaths
        //res.tempFilePaths指图片的本地临时路径数组
        //res.tempFilePaths是一个数组，传参的时候需要指定是哪一个
        //console.log(res.tempFilePaths);
        //this.uploadFile_toCloud(res.tempFilePaths[0]);//传入形参
        //多张图片的时候，遍历数组tempFilePaths循环调用方法
        //   res.tempFilePaths.forEach((item,index) => {
        //     var save_path=+"_"+index+".jpg"
        //     this.uploadFile_toCloud(save_path,item);
        //   });
        var old_path = this.data.img_TmpPath
        var new_path = old_path.concat(res.tempFilePaths)
        this.setData({
          img_TmpPath: new_path //绑定文件临时地址，为了渲染在前端
        })
      },
      fail: err => {
        console.log(err);
      }
    })
  },
  //上传图片到云存储
  uploadImg_toCloud(path_inCloud, tmpPath) {
    //tmpPath:图片的本地临时路径
    //path_inCloud：图片在云存储的存储路径
    var tmpPath = this.data.img_TmpPath
    if (tmpPath.length > 0) {
      tmpPath.forEach((item, index) => {
        wx.cloud.uploadFile({
          cloudPath: new Date().getTime() + "_" + index + ".jpg", //云存储文件名
          filePath: item, // 文件路径
        }).then(res => {
          // get resource ID
          console.log(res)
        }).catch(error => {
          console.log(error);
          // handle error
        })
      });
    } else {
      console.log("请先选择要上传的图片");
    }


  },
  //获取图片的宽度
  getImgwidth() {
    var screen_wth = wx.getSystemInfoSync().screenWidth
    console.log("屏幕的宽度是：" + screen_wth);
    var img_wth = (screen_wth - 20 - 8) / 3 //减去图片之间的padding值（10px*2）
    console.log("图片的宽度是：" + img_wth);
    this.setData({
      img_width: img_wth
    })
    console.log("图片的宽度是：" + this.data.img_width);
    //console.log(wth);
  },
  //关闭图像按钮
  close_Img(e) {
    var idx = e.currentTarget.dataset.index //获取到当前访问的数组下标
    //通过在整个图像数组中删除此下标的元素来实现删除图片功能。
    var TmpPath = this.data.img_TmpPath
    TmpPath.splice(idx, 1) //在数组TmpPath中从下标idx开始，删除1个元素
    this.setData({ //更新修改后的数据，让前端来渲染
      img_TmpPath: TmpPath
    })
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getImgwidth()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})