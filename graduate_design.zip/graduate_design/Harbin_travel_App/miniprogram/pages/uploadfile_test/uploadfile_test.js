// pages/uploadfile_test/uploadfile_test.js
const db=wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    iptValue: "", //输入框输入的内容
    upFileArr: [], //文件数组
    fileList:[],
    cloudFile_path:[]//文件的云端真实路径
  },
  //获取输入框输入的内容
  bindIpt(res) {
    this.setData({
      iptValue: res.detail.value
    })
  },
  //选择文件
  chooseFile() {
    wx.chooseMessageFile({
      success: (res) => {
        this.setData({
          upFileArr: res.tempFiles
        })
      },
    })
  },
  //点击提交按钮s
  SubmitFile() {
    wx.showLoading({
      title: '正在上传，请等待',
    })
    var fileArr = this.data.upFileArr
    fileArr.forEach((item, index) => {
      var tmp = item.path
      var Name = item.time + "_" + index + item.name
      //if(index==fileArr.length-1)
      this.uploadFile_toCloud(tmp, Name,index) //发送到云存储

    })
  },
  //将文件上传到云存储
  uploadFile_toCloud(tmpPath, fileName,index) {
    wx.cloud.uploadFile({
      cloudPath: fileName,
      filePath: tmpPath, // 文件路径
    }).then(res => {
      this.data.upFileArr[index].path=res.fileID//将原本的文件临时路径替换为对应的云端cloud路径
      this.data.cloudFile_path.push(res.fileID)//将每一次上传到云存储得到的cloud路径添加到cloud路径树组内
      if(this.data.upFileArr.length==this.data.cloudFile_path.length){//判断当前的一组文件是否都上传到了云存储
        this.uploadFile_toDB()//将数据上传到云数据库
      }
        
      console.log(res.fileID)
    }).catch(error => {
      // handle error
    })

  },

  //将文件发送到数据库
  uploadFile_toDB(){
    db.collection("clouddemo").add({
      data:{
        title:this.data.iptValue,
        upFileArr:this.data.upFileArr
      }
    }).then(res=>{
      wx.hideLoading({
        success: (res) => {},
      })
      wx.showToast({
        title: '发布成功',
        
      })
      this.getFile_List()
      console.log(res);
    })

  },
  //渲染初始化列表
  getFile_List(){
    db.collection("clouddemo").get()
    .then(res=>{
      this.setData({
        fileList:res.data
      })
    })
  },
  //下载文件
  download_File(e){
    var fileid=e.currentTarget.dataset.fileid
    console.log(e);
    wx.cloud.downloadFile({
      fileID:fileid//这里的fileID必须是cloudid，不能是临时路径
    }).then(res => {
      wx.openDocument({
        filePath: res.tempFilePath,
        success: function (res) {
          console.log('打开文档成功')
        }
      })
    }).catch(error => {
      // handle error
    })
  },








  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getFile_List()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})